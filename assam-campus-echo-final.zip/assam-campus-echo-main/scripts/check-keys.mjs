// Usage: npm run check:keys
// Reports whether each API key is present in .env (never prints the key) and makes
// one tiny live call per key to see if the provider accepts it.
try { process.loadEnvFile(); } catch { console.log("No .env file found in this folder.\n"); }

const checks = [
  {
    name: "GROQ_API_KEY (SyncBot chat, English)",
    key: process.env.GROQ_API_KEY,
    call: (k) => fetch("https://api.groq.com/openai/v1/models", { headers: { Authorization: `Bearer ${k}` } }),
  },
  {
    name: "GEMINI_API_KEY (SyncBot, Assamese)",
    key: process.env.GEMINI_API_KEY,
    call: async (k) => {
      const model = process.env.GEMINI_MODEL || "gemini-2.5-flash";
      const r = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent`, {
        method: "POST",
        headers: { "x-goog-api-key": k, "Content-Type": "application/json" },
        body: JSON.stringify({
          contents: [{ parts: [{ text: "Translate to Assamese: Hello" }] }],
          generationConfig: { maxOutputTokens: 40, thinkingConfig: { thinkingBudget: 0 } },
        }),
      });
      if (r.ok) {
        const j = await r.clone().json();
        const text = j.candidates?.[0]?.content?.parts?.[0]?.text?.trim();
        console.log(`   sample reply: ${text ?? "(empty)"}`);
      }
      return r;
    },
  },
];

let bad = 0;
for (const c of checks) {
  console.log(c.name);
  if (!c.key) { console.log("   ✗ missing — add it to .env\n"); bad++; continue; }
  console.log(`   ✓ present (${c.key.length} characters)`);
  try {
    const r = await c.call(c.key);
    if (r.ok) console.log("   ✓ provider accepted the key — working\n");
    else { console.log(`   ✗ provider answered ${r.status} ${r.status === 400 || r.status === 401 || r.status === 403 ? "— key rejected or wrong" : ""}\n`); bad++; }
  } catch (e) {
    console.log(`   ✗ could not reach the provider (${e.cause?.code ?? e.message}) — check internet/firewall\n`); bad++;
  }
}
process.exit(bad ? 1 : 0);
