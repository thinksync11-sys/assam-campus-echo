import { defineConfig } from "drizzle-kit";

// drizzle-kit does not read .env on its own
try { process.loadEnvFile(); } catch { /* no .env file */ }

export default defineConfig({
  dialect: "postgresql",
  schema: "./drizzle/schema.ts",
  out: "./drizzle/migrations",
  dbCredentials: {
    url: process.env.LOVABLE_DB_MIGRATION_URL ?? "",
  },
});
