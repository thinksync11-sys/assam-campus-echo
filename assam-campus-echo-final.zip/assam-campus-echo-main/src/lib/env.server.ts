// One place for server-side secrets. Importing this file loads `.env` (once) into
// process.env, without overriding anything the host already set. Where there is no
// file access (some edge runtimes) it quietly does nothing and the host's own
// environment variables are used instead.
let loaded = false;
export function loadEnv() {
  if (loaded) return;
  loaded = true;
  try {
    (process as unknown as { loadEnvFile?: (path?: string) => void }).loadEnvFile?.();
  } catch { /* no .env file here — fine */ }
}
loadEnv();

/** Read a server-side setting. Empty strings count as "not set". */
export function env(name: string): string | undefined {
  return process.env[name] || undefined;
}
