import { env } from "./env.server";
import { HELPBOT_LIMITS, buildSystemPrompt, cleanMessages } from "./helpbot.policy";

const GROQ_URL = "https://api.groq.com/openai/v1/chat/completions";
const DEFAULT_MODEL = "llama-3.3-70b-versatile";
const GEMINI_BASE = "https://generativelanguage.googleapis.com/v1beta/models";
const DEFAULT_GEMINI_MODEL = "gemini-2.5-flash";

// Simple sliding-window limiter. Lives in process memory, so on serverless hosts
// it is per-instance — good enough to blunt abuse, not a hard guarantee.
const hits = new Map<string, number[]>();
function tooMany(ip: string) {
  const now = Date.now();
  const recent = (hits.get(ip) ?? []).filter((t) => now - t < 60_000);
  recent.push(now);
  hits.set(ip, recent);
  if (hits.size > 5000) for (const [k, v] of hits) if (now - v[v.length - 1] > 60_000) hits.delete(k);
  return recent.length > HELPBOT_LIMITS.perMinute;
}

const fail = (error: string, status: number) => Response.json({ error }, { status });

type Msgs = { role: "user" | "assistant"; content: string }[];
type Provider = {
  url: string;
  headers: Record<string, string>;
  body: unknown;
  // pull the text out of one parsed streaming frame
  pick: (frame: any) => string | undefined;
};

// Groq: OpenAI-style chat completions.
function groqRequest(key: string, system: string, messages: Msgs): Provider {
  return {
    url: GROQ_URL,
    headers: { Authorization: `Bearer ${key}`, "Content-Type": "application/json" },
    body: {
      model: env("HELPBOT_MODEL") || DEFAULT_MODEL, stream: true, temperature: 0.4,
      max_tokens: HELPBOT_LIMITS.maxReplyTokens,
      messages: [{ role: "system", content: system }, ...messages],
    },
    pick: (f) => f.choices?.[0]?.delta?.content,
  };
}

// Gemini: used for Assamese replies, where it writes noticeably better than the Groq model.
function geminiRequest(key: string, system: string, messages: Msgs): Provider {
  const model = env("GEMINI_MODEL") || DEFAULT_GEMINI_MODEL;
  return {
    url: `${GEMINI_BASE}/${model}:streamGenerateContent?alt=sse`,
    headers: { "x-goog-api-key": key, "Content-Type": "application/json" },
    body: {
      systemInstruction: { parts: [{ text: system }] },
      contents: messages.map((m) => ({ role: m.role === "assistant" ? "model" : "user", parts: [{ text: m.content }] })),
      generationConfig: { temperature: 0.4, maxOutputTokens: HELPBOT_LIMITS.maxReplyTokens, thinkingConfig: { thinkingBudget: 0 } },
    },
    pick: (f) => f.candidates?.[0]?.content?.parts?.map((p: { text?: string }) => p.text ?? "").join("") || undefined,
  };
}

export async function handleHelpbot(request: Request) {
  const groqKey = env("GROQ_API_KEY");
  const geminiKey = env("GEMINI_API_KEY");

  let body: { messages?: unknown; lang?: unknown };
  const ip = request.headers.get("x-forwarded-for")?.split(",")[0]?.trim() || "local";
  if (!groqKey && !geminiKey) return fail("The helper is not switched on yet.", 503);
  if (tooMany(ip)) return fail("You're sending messages quickly. Please wait a moment.", 429);

  try { body = await request.json(); } catch { return fail("Invalid request.", 400); }
  const messages = cleanMessages(body.messages);
  if (!messages) return fail("Please type a message first.", 400);
  const lang = body.lang === "as" ? "as" : "en";
  const system = buildSystemPrompt(lang);

  // Assamese -> Gemini when its key is present; everything else (and the fallback) -> Groq.
  const provider = lang === "as" && geminiKey ? geminiRequest(geminiKey, system, messages)
    : groqKey ? groqRequest(groqKey, system, messages)
    : geminiKey ? geminiRequest(geminiKey, system, messages) : null;
  if (!provider) return fail("The helper is not switched on yet.", 503);

  let upstream: Response;
  try {
    upstream = await fetch(provider.url, {
      method: "POST", signal: request.signal, headers: provider.headers, body: JSON.stringify(provider.body),
    });
  } catch {
    return fail("Could not reach the helper. Please try again.", 502);
  }
  if (!upstream.ok || !upstream.body) {
    return fail(upstream.status === 429 ? "The helper is busy right now. Try again shortly." : "The helper had a problem. Please try again.", 502);
  }

  // Both providers stream server-sent events; forward only the text so the browser stays simple.
  const decoder = new TextDecoder();
  const encoder = new TextEncoder();
  let buffer = "";
  const reader = upstream.body.getReader();
  const stream = new ReadableStream<Uint8Array>({
    async pull(controller) {
      const { done, value } = await reader.read();
      if (done) return controller.close();
      buffer += decoder.decode(value, { stream: true });
      const lines = buffer.split(/\r?\n/);
      buffer = lines.pop() ?? "";
      for (const line of lines) {
        const data = line.startsWith("data:") ? line.slice(5).trim() : "";
        if (!data || data === "[DONE]") continue;
        try {
          const piece = provider.pick(JSON.parse(data));
          if (piece) controller.enqueue(encoder.encode(piece));
        } catch { /* partial frame, ignore */ }
      }
    },
    cancel() { void reader.cancel(); },
  });
  return new Response(stream, { headers: { "Content-Type": "text/plain; charset=utf-8", "Cache-Control": "no-store" } });
}
