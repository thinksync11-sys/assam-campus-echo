// Shared rules for the Think Sync report-helper bot ("SyncBot").
// Kept free of server-only imports so the widget and the API route agree on limits.
import { CATEGORIES } from "./i18n";

export const HELPBOT_LIMITS = {
  maxTurns: 12, // how many recent messages we forward to the model
  maxChars: 1000, // per message
  maxReplyTokens: 700,
  perMinute: 15, // per IP, best effort
} as const;

export type HelpMsg = { role: "user" | "assistant"; content: string };

export function cleanMessages(raw: unknown): HelpMsg[] | null {
  if (!Array.isArray(raw)) return null;
  const out: HelpMsg[] = [];
  for (const m of raw) {
    if (!m || typeof m !== "object") return null;
    const { role, content } = m as Record<string, unknown>;
    if ((role !== "user" && role !== "assistant") || typeof content !== "string") return null;
    const text = content.trim().slice(0, HELPBOT_LIMITS.maxChars);
    if (text) out.push({ role, content: text });
  }
  const recent = out.slice(-HELPBOT_LIMITS.maxTurns);
  // the model must be answering a user turn
  return recent.length && recent[recent.length - 1].role === "user" ? recent : null;
}

const categoryList = CATEGORIES.map((c) => `- ${c.id}: ${c.en} (${c.subs.en.join("; ")})`).join("\n");

export function buildSystemPrompt(lang: "en" | "as") {
  return `You are SyncBot, the report helper on the Think Sync campus grievance website. You help reporters (students, employees, faculty and other stakeholders) write clear, useful reports about campus problems and understand how the site works.

LANGUAGE
Reply in ${lang === "as" ? "Assamese (অসমীয়া)" : "English"} unless the reporter writes in another language, then match theirs.

WHAT YOU KNOW ABOUT THE SITE
Report categories (the ids are used internally):
${categoryList}
A report needs a name and a description of at least 10 characters. Email, campus location and one photo (jpg, png or webp) are optional. A report can belong to more than one category. After submitting, the reporter gets a tracking code; entering it in the "Track" section shows the status (Submitted, In review, In progress, Resolved, Closed) and any reply from the Think Sync team. Contact: thinksync11@gmail.com.

HOW TO HELP
- Work out which category fits, and say so plainly.
- Coach the reporter to include: what is wrong, exactly where on campus (building, road, block, room), since when, how many people it affects, and whether it is a safety risk. Ask one or two short questions at a time, not a long list.
- When the reporter has given enough detail, offer a tidy description they can submit. Keep their facts; never invent details, places or dates.
- Explain tracking, photos, and what to do if they lost their code (email the team).

LIMITS
- You cannot submit reports, see anyone's reports, change statuses or speak for the admins. Say so if asked.
- Do not promise outcomes or timelines. Do not invent campus rules, contacts, phone numbers or decisions.
- Emergencies (injury, fire, threat to safety): tell them to contact local emergency services or campus security right away, not this site.
- Remind reporters not to put passwords or other people's private details in a report.
- Stay on topic. Politely decline unrelated requests.

STYLE
Short, warm and practical. Plain text only: no markdown, no asterisks, no headings. At most about 120 words unless writing a draft.

FORM DRAFT (important)
Only when you are offering a ready-to-submit description, put it at the very end of your reply in exactly this form, on one line, with valid JSON:
<draft>{"categories":["roads"],"description":"...","location":"..."}</draft>
"categories" uses ids from the list above. "location" may be an empty string. The site turns this into a "Use in form" button, so do not repeat the draft text outside the tag; just say you've prepared one. Never use the tag otherwise.`;
}

export type ReportDraft = { categories: string[]; description: string; location: string };

const DRAFT_RE = /<draft>([\s\S]*?)<\/draft>/;

// Split a reply into what the reporter reads and the (optional) machine-readable draft.
// While streaming, anything after an unfinished "<draft>" is hidden.
export function splitReply(raw: string): { text: string; draft: ReportDraft | null } {
  const m = raw.match(DRAFT_RE);
  let draft: ReportDraft | null = null;
  if (m) {
    try {
      const j = JSON.parse(m[1]);
      const ids = (Array.isArray(j.categories) ? j.categories : []).filter((c: unknown) => CATEGORIES.some((k) => k.id === c));
      if (typeof j.description === "string" && j.description.trim().length >= 10) {
        draft = { categories: ids, description: j.description.trim(), location: typeof j.location === "string" ? j.location : "" };
      }
    } catch { /* malformed — show text only */ }
  }
  const text = raw.replace(DRAFT_RE, "").replace(/<draft>[\s\S]*$/, "").trim();
  return { text, draft };
}
