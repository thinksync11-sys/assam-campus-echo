import { createFileRoute } from "@tanstack/react-router";
import { handleHelpbot } from "@/lib/helpbot.server";

export const Route = createFileRoute("/api/helpbot")({
  server: { handlers: { POST: ({ request }) => handleHelpbot(request) } },
});
