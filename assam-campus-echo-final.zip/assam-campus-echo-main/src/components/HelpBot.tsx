import { useEffect, useRef, useState, type FormEvent } from "react";
import type { Lang } from "@/lib/i18n";
import { splitReply, type HelpMsg, type ReportDraft } from "@/lib/helpbot.policy";

export type { ReportDraft };

const COPY = {
  en: {
    open: "Need help reporting?", title: "SyncBot", sub: "Your report helper",
    hello: "Hi, I'm SyncBot. Tell me what's wrong on campus and I'll help you write it up so the team can act on it.",
    placeholder: "Describe the problem…", send: "Send", close: "Close helper", clear: "Start over",
    thinking: "SyncBot is typing", useDraft: "Use in form →", applied: "Added to the form ✓",
    error: "Something went wrong. Please try again.", note: "Can't submit or see reports · not official advice",
    chips: ["Which category fits my issue?", "What should I write in my report?", "How do I track my complaint?", "I lost my tracking code"],
  },
  as: {
    open: "অভিযোগ জনাবলৈ সহায় লাগে?", title: "SyncBot", sub: "আপোনাৰ অভিযোগ সহায়ক",
    hello: "নমস্কাৰ, মই SyncBot। চৌহদত কি সমস্যা হৈছে কওক, দলে যাতে ব্যৱস্থা ল'ব পাৰে তাৰ বাবে লিখাত সহায় কৰিম।",
    placeholder: "সমস্যাটো বৰ্ণনা কৰক…", send: "পঠাওক", close: "সহায়ক বন্ধ কৰক", clear: "নতুনকৈ আৰম্ভ",
    thinking: "SyncBot লিখি আছে", useDraft: "ফৰ্মত ব্যৱহাৰ কৰক →", applied: "ফৰ্মত যোগ হ'ল ✓",
    error: "কিবা ভুল হ'ল। অনুগ্ৰহ কৰি আকৌ চেষ্টা কৰক।", note: "অভিযোগ দাখিল বা চাব নোৱাৰে · চৰকাৰী পৰামৰ্শ নহয়",
    chips: ["মোৰ সমস্যা কোনটো শ্ৰেণীত পৰে?", "অভিযোগত কি লিখিম?", "অভিযোগ কেনেকৈ অনুসৰণ কৰিম?", "মই অনুসৰণ ক'ড হেৰুৱালোঁ"],
  },
} as const;

const STORE_KEY = "thinksync.helpbot.v1";
export function HelpBot({ lang, onApplyDraft }: { lang: Lang; onApplyDraft: (d: ReportDraft) => void }) {
  const c = COPY[lang];
  const [open, setOpen] = useState(false);
  const [msgs, setMsgs] = useState<HelpMsg[]>([]);
  const [input, setInput] = useState("");
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState<string | null>(null);
  const [applied, setApplied] = useState<number | null>(null);
  const abortRef = useRef<AbortController | null>(null);
  const endRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLTextAreaElement>(null);

  useEffect(() => {
    try { const s = sessionStorage.getItem(STORE_KEY); if (s) setMsgs(JSON.parse(s)); } catch { /* private mode */ }
  }, []);
  useEffect(() => {
    if (busy) return;
    try { sessionStorage.setItem(STORE_KEY, JSON.stringify(msgs)); } catch { /* ignore */ }
  }, [msgs, busy]);
  useEffect(() => { endRef.current?.scrollIntoView({ behavior: "smooth", block: "end" }); }, [msgs, open]);
  useEffect(() => { if (open) inputRef.current?.focus(); }, [open]);
  useEffect(() => {
    if (!open) return;
    const onKey = (e: KeyboardEvent) => e.key === "Escape" && setOpen(false);
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [open]);
  useEffect(() => () => abortRef.current?.abort(), []);

  async function ask(text: string) {
    const content = text.trim();
    if (!content || busy) return;
    const next: HelpMsg[] = [...msgs, { role: "user", content }];
    setMsgs([...next, { role: "assistant", content: "" }]);
    setInput(""); setErr(null); setBusy(true);
    const ctl = new AbortController();
    abortRef.current = ctl;
    try {
      const res = await fetch("/api/helpbot", {
        method: "POST", signal: ctl.signal, headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ messages: next, lang }),
      });
      if (!res.ok || !res.body) {
        const j = await res.json().catch(() => null);
        throw new Error(j?.error || c.error);
      }
      const reader = res.body.getReader();
      const dec = new TextDecoder();
      let acc = "";
      for (;;) {
        const { done, value } = await reader.read();
        if (done) break;
        acc += dec.decode(value, { stream: true });
        setMsgs([...next, { role: "assistant", content: acc }]);
      }
      if (!acc.trim()) throw new Error(c.error);
    } catch (e) {
      if (ctl.signal.aborted) return;
      setMsgs(next);
      setErr(e instanceof Error ? e.message : c.error);
    } finally { setBusy(false); }
  }

  const onSubmit = (e: FormEvent) => { e.preventDefault(); ask(input); };
  const reset = () => { abortRef.current?.abort(); setMsgs([]); setErr(null); setBusy(false); setApplied(null); };

  return (
    <>
      <button onClick={() => setOpen((v) => !v)} aria-expanded={open} aria-controls="syncbot-panel"
        className="fixed bottom-5 right-5 z-50 flex items-center gap-2 rounded-full bg-gradient-primary px-5 py-3 text-sm font-semibold text-primary-foreground shadow-glow transition-transform hover:scale-105">
        <span className="text-lg leading-none" aria-hidden>{open ? "×" : "✦"}</span>
        <span className="italic">{open ? c.close : c.open}</span>
      </button>

      {open && (
        <section id="syncbot-panel" role="dialog" aria-label={c.title}
          className="animate-rise fixed inset-x-3 bottom-20 z-50 flex max-h-[min(36rem,calc(100dvh-7rem))] flex-col overflow-hidden rounded-2xl border border-border bg-card shadow-glow sm:inset-x-auto sm:right-5 sm:w-[24rem]">
          <header className="flex items-center justify-between border-b border-border bg-gradient-hero px-4 py-3">
            <div>
              <p className="font-display text-xl italic leading-none">Sync<span className="text-gradient">Bot</span></p>
              <p className="mt-1 text-xs text-muted-foreground">{c.sub}</p>
            </div>
            {msgs.length > 0 && (
              <button onClick={reset} className="text-xs text-muted-foreground underline decoration-primary underline-offset-4 hover:text-foreground">{c.clear}</button>
            )}
          </header>

          <div className="flex-1 space-y-3 overflow-y-auto px-4 py-4 text-sm" aria-live="polite">
            <Bubble role="assistant">{c.hello}</Bubble>
            {msgs.length === 0 && (
              <div className="flex flex-wrap gap-2 pt-1">
                {c.chips.map((q) => (
                  <button key={q} onClick={() => ask(q)}
                    className="rounded-full border border-border px-3 py-1.5 text-left text-xs italic text-muted-foreground transition-colors hover:border-primary hover:text-foreground">{q}</button>
                ))}
              </div>
            )}
            {msgs.map((m, i) => {
              const { text, draft } = m.role === "assistant" ? splitReply(m.content) : { text: m.content, draft: null };
              const pending = busy && i === msgs.length - 1 && m.role === "assistant";
              return (
                <div key={i} className="space-y-2">
                  {(text || pending) && <Bubble role={m.role}>{text || <Dots label={c.thinking} />}</Bubble>}
                  {draft && !pending && (
                    <button onClick={() => { onApplyDraft(draft); setApplied(i); setOpen(false); }}
                      className="rounded-full border border-primary bg-accent px-4 py-2 text-xs font-semibold transition-transform hover:scale-105">
                      {applied === i ? c.applied : c.useDraft}
                    </button>
                  )}
                </div>
              );
            })}
            {err && <p className="text-xs text-destructive">{err}</p>}
            <div ref={endRef} />
          </div>

          <form onSubmit={onSubmit} className="border-t border-border p-3">
            <div className="flex items-end gap-2">
              <textarea ref={inputRef} value={input} rows={1} maxLength={1000} placeholder={c.placeholder}
                onChange={(e) => setInput(e.target.value)}
                onKeyDown={(e) => { if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); ask(input); } }}
                className="field max-h-28 resize-none !py-2.5 text-sm" />
              <button disabled={busy || !input.trim()}
                className="rounded-full bg-gradient-primary px-4 py-2.5 text-sm font-semibold text-primary-foreground transition-opacity disabled:opacity-50">{c.send}</button>
            </div>
            <p className="mt-2 text-center text-[11px] italic text-muted-foreground">{c.note}</p>
          </form>
        </section>
      )}
    </>
  );
}

function Bubble({ role, children }: { role: "user" | "assistant"; children: React.ReactNode }) {
  return (
    <div className={role === "user" ? "flex justify-end" : "flex"}>
      <p className={`max-w-[88%] whitespace-pre-wrap rounded-2xl px-3.5 py-2.5 leading-relaxed ${role === "user" ? "bg-gradient-primary text-primary-foreground" : "border border-border bg-secondary"}`}>{children}</p>
    </div>
  );
}

function Dots({ label }: { label: string }) {
  return (
    <span className="inline-flex items-center gap-1" role="status" aria-label={label}>
      {[0, 1, 2].map((i) => <span key={i} className="syncbot-dot h-1.5 w-1.5 rounded-full bg-primary-glow" style={{ animationDelay: `${i * 0.15}s` }} />)}
    </span>
  );
}
