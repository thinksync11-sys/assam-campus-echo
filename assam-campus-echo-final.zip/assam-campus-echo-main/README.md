# Assam Campus Echo


Think Sync — Existing Website Modifications



### 1. UI/UX Design Updates

- Apply a consistent **purple and black** theme throughout the website.

- Maintain a modern, premium, clean, and user-friendly interface.

- Add smooth animations and transitions wherever appropriate.

- Use *italic typography* and underlined text wherever visually suitable.

- Replace the default cursor with a unique, custom-designed cursor.

- Ensure the website remains fully responsive across desktop, tablet, and mobile devices.

- Preserve the existing website structure, features, and functionality unless a change is specifically required.



### 2. Complaint Categorization:



**1. Roads & Transportation**

- Damaged roads and potholes.

- Excessive dust on campus roads.



**2. Cleanliness & Waste Management**

- Insufficient dustbins.

- Irregular garbage collection or cleaning.



**3. Landscaping & Campus Maintenance**

- Excessively tall grass.

- Poorly maintained gardens and campus surroundings.



**4. Buildings & Infrastructure**

- Damaged or poorly maintained classrooms.

- Issues with campus buildings and facilities.



**5. Laboratories & Academic Resources**

- Lack of laboratory materials and components.

- Insufficient or damaged academic equipment.



**6. Language Barriers for Students**

- Difficulty communicating due to language differences.

- Lack of multilingual assistance and information.

one category for other suggestions 

### 3. Development Team Information:







- **Team Name:** Think Sync

- **Email:** thinksync11@gmail.com

**Live app**: https://assam-campus-echo.lovable.app

## Development

Prefer working locally? You need Node.js and npm — [install with nvm](https://github.com/nvm-sh/nvm#installing-and-updating).

```sh
git clone <this-repository-url>
cd <repository-name>
npm i
npm run dev
```

## SyncBot — report helper

A floating assistant on the home page that helps reporters pick a category, write a clear description and understand tracking. It can draft a report and send it into the form with one click (the reporter still reviews and submits).

- UI: `src/components/HelpBot.tsx` (follows the EN / অস toggle)
- Rules and system prompt: `src/lib/helpbot.policy.ts`
- Server route: `POST /api/helpbot` → `src/lib/helpbot.server.ts` (calls Groq, streams text back, rate-limited per IP)

Setup: put your key in `.env` as `GROQ_API_KEY=...` (copy `.env.example` if you don't have one). `.env` is git-ignored and loaded on the server by `src/lib/env.server.ts`; on a host, set the same names in its environment settings. Without it the bot politely says it isn't switched on. SyncBot cannot submit reports or read anyone's complaints.
